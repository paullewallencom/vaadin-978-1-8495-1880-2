package com;

import com.vaadin.ui.VerticalLayout;

/**
 * @author Ondrej Kvasnovsky
 */
public class ContentLayout extends VerticalLayout {
}
