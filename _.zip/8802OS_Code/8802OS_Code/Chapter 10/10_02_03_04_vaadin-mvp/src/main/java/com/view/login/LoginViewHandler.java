package com.view.login;

public interface LoginViewHandler {

    void login();
}
