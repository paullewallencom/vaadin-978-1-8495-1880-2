package com.view.tag;

public interface TagLayout {

    public void setHandler(TagViewHandler handler);

    public void init();
}
