package com.view.tag;

public interface TagViewHandler {

    void addTag();

    void showTagList();
}
