package com.app;

public interface UserService {

    User login(String username, String password);
}
