package com.app;

public class SystemStatusService {

    public static String getValue() {
        return "Offline";
    }
}
