package com.packtpub.vaadin.close;

import com.vaadin.annotations.JavaScript;
import com.vaadin.ui.AbstractJavaScriptComponent;

@SuppressWarnings("serial")
@JavaScript({ "goodbye_world.js" })
public class GoodbyeWorld extends AbstractJavaScriptComponent  {

}
