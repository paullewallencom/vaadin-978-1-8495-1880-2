1) Create a simple Vaadin project with a package:
   com.packtpub.vaadin
2) Insert Java source code to this package.