package com.packtpub.vaadin.widget.client.countedtextfield;

@SuppressWarnings("serial")
public class CountedTextFieldState extends com.vaadin.shared.ui.textfield.AbstractTextFieldState {

    {
        primaryStyleName = null;
    }

}