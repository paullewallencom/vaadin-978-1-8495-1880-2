package com.packtpub.vaadin.widget.client.integertextfield;

@SuppressWarnings("serial")
public class IntegerTextFieldState extends com.vaadin.shared.ui.textfield.AbstractTextFieldState {

}