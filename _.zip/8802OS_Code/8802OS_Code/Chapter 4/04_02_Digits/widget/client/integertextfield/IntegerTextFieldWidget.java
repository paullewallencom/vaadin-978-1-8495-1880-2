package com.packtpub.vaadin.widget.client.integertextfield;

import com.google.gwt.user.client.ui.TextBox;

public class IntegerTextFieldWidget extends TextBox {

    public static final String CLASSNAME = "integertextfield";

    public IntegerTextFieldWidget() {        
        setStyleName(CLASSNAME);
    }

}