package com.packtpub.vaadin.widget.client.chromahashpasswordfield;

@SuppressWarnings("serial")
public class ChromaHashPasswordFieldState extends com.vaadin.shared.ui.textfield.AbstractTextFieldState {
    {
        primaryStyleName = null;
    }
}