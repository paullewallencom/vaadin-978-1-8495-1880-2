package com.packtpub.vaadin.widget.client.tristatecheckbox;

@SuppressWarnings("serial")
public class TriStateCheckboxState extends com.vaadin.shared.ui.checkbox.CheckBoxState {
   
    public String text = "This is TriStateCheckbox";    
    public boolean indeterminate = false;

}