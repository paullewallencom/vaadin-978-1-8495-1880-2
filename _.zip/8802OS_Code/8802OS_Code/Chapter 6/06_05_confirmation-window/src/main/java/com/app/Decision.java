package com.app;

import com.vaadin.ui.Button;

/**
 * @author Ondrej Kvasnovsky
 */
public class Decision {

    public void yes(Button.ClickEvent event) {
    }

    public void no(Button.ClickEvent event) {
    }
}
