package com.packtpub.vaadin;

/**
 * @author Ondrej Kvasnovsky
 */
public interface UserService {

    public User getUser();
}
