package vaadin.grails.gorm

class User {

    String name

    static constraints = {
    }
}
