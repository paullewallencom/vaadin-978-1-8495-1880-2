package vaadin.grails.services

class User {

    String name

    static constraints = {
    }
}
